# 🦅 Halcón — Web App de Gestión de Pedidos

Aplicación web para **Halcón Distribuidora de Materiales de Construcción**.  
Permite el seguimiento del ciclo de vida de pedidos desde su registro hasta su entrega.

---

## 📦 Stack Tecnológico

| Capa       | Tecnología                          |
|------------|-------------------------------------|
| Backend    | PHP 8.2 · Laravel 11                |
| Frontend   | Blade · Bootstrap 5.3 · Toastr.js  |
| Base de datos | MySQL 8                          |
| Auth       | Laravel Breeze                      |
| Storage    | Laravel Storage (public disk)       |

---

## 🚀 Instalación

```bash
# 1. Clonar el repositorio
git clone https://github.com/EderZ23/halcon-web-app.git
cd halcon-web-app

# 2. Instalar dependencias
composer install
npm install && npm run build

# 3. Configurar entorno
cp .env.example .env
php artisan key:generate

# 4. Configurar base de datos en .env
DB_DATABASE=halcon_db
DB_USERNAME=root
DB_PASSWORD=tu_password

# 5. Ejecutar migraciones y seeders
php artisan migrate --seed

# 6. Crear enlace de almacenamiento
php artisan storage:link

# 7. Iniciar servidor
php artisan serve
```

---

## 👤 Usuarios de Prueba (Seeder)

| Correo               | Contraseña   | Rol           |
|----------------------|--------------|---------------|
| admin@halcon.mx      | halcon2024   | Administrador |
| ventas@halcon.mx     | ventas123    | Ventas        |
| compras@halcon.mx    | compras123   | Compras       |
| almacen@halcon.mx    | almacen123   | Almacén       |
| ruta@halcon.mx       | ruta12345    | Ruta          |

---

## 🗂 Estructura del Proyecto

```
app/
├── Http/Controllers/
│   ├── HomeController.php        ← Rastreo público
│   ├── DashboardController.php   ← Panel principal
│   ├── OrderController.php       ← CRUD pedidos
│   └── UserController.php        ← CRUD usuarios (Admin)
├── Models/
│   ├── Order.php                 ← Modelo de pedido + SoftDeletes
│   ├── User.php                  ← Modelo de usuario
│   └── Role.php                  ← Modelo de rol/departamento
└── Policies/
    └── OrderPolicy.php           ← Autorización por rol

database/
├── migrations/
│   └── 2024_01_01_create_halcon_tables.php
├── seeders/
│   └── DatabaseSeeder.php        ← Roles, usuarios y pedidos de prueba
└── factories/
    └── OrderFactory.php

resources/views/
├── layouts/
│   ├── app.blade.php             ← Layout autenticado (sidebar + topbar)
│   └── guest.blade.php           ← Layout público
├── public/
│   └── home.blade.php            ← Rastreo de pedido (sin login)
├── auth/
│   └── login.blade.php
├── orders/
│   ├── index.blade.php           ← Lista con filtros
│   ├── form.blade.php            ← Crear / Editar
│   ├── show.blade.php            ← Detalle + cambio de estado + fotos
│   ├── archived.blade.php        ← Pedidos eliminados lógicamente
│   └── dashboard.blade.php       ← Dashboard con stats
└── users/
    ├── index.blade.php
    └── form.blade.php

routes/
└── web.php
```

---

## 🔄 Ciclo de Vida de un Pedido

```
Cliente llama → Ventas registra pedido (status: ordered)
                    ↓
             Almacén lo toma (status: in_process)
                    ↓
         Almacén carga la unidad (status: in_route)
         Ruta sube foto de carga
                    ↓
         Ruta entrega y sube foto (status: delivered)
                    ↓
         Cliente consulta evidencia en portal público
```

---

## 🔐 Permisos por Rol

| Acción                    | Admin | Ventas | Compras | Almacén | Ruta |
|---------------------------|:-----:|:------:|:-------:|:-------:|:----:|
| Ver pedidos               | ✅    | ✅     | ✅      | ✅      | ✅   |
| Crear pedido              | ✅    | ✅     |         |         |      |
| Editar datos del pedido   | ✅    | ✅     |         |         |      |
| Cambiar a En Proceso      | ✅    |        |         | ✅      |      |
| Cambiar a En Ruta         | ✅    |        |         | ✅      |      |
| Cambiar a Entregado       | ✅    |        |         |         | ✅   |
| Subir foto de evidencia   | ✅    |        |         |         | ✅   |
| Archivar / Restaurar      | ✅    |        |         |         |      |
| Gestionar usuarios        | ✅    |        |         |         |      |

---

## 📄 Vistas Implementadas (Outcome 3)

### Públicas (sin registro)
- `/` — Portal de rastreo con búsqueda por N° Cliente + N° Factura
  - Muestra estado actual con línea de tiempo visual
  - Si status = `delivered`, muestra foto de evidencia

### Autenticadas
- `/dashboard` — Tarjetas de estadísticas + pedidos recientes + accesos rápidos
- `/pedidos` — Lista con filtros (factura, cliente, fecha, estado)
- `/pedidos/nuevo` — Formulario de creación
- `/pedidos/{id}` — Detalle con cambio de estado y carga de fotos
- `/pedidos/{id}/editar` — Edición de datos
- `/pedidos/archivados/lista` — Pedidos con soft delete + restaurar
- `/usuarios` — Lista de usuarios (Admin)
- `/usuarios/nuevo` — Crear usuario con asignación de rol (Admin)
- `/usuarios/{id}/editar` — Editar usuario (Admin)

---

## 🔔 Notificaciones

Se utiliza **Toastr.js** para alertas no intrusivas:
- ✅ `success` — Pedido creado / Estado actualizado / Usuario guardado
- ❌ `error` — Errores de validación o permisos
- ℹ️ `info` — Pedido archivado

---

## 📝 Cambios — Outcome 3 (v1.1 — correcciones)

- ✅ Modelos `Order`, `User`, `Role` con relaciones y scopes
- ✅ Migración unificada con foreign keys y soft deletes
- ✅ `DatabaseSeeder` con roles, empleados y pedidos de prueba
- ✅ `OrderFactory` para testing
- ✅ `OrderPolicy` con autorización por departamento
- ✅ Controladores: `HomeController`, `DashboardController`, `OrderController`, `UserController`
- ✅ Todas las vistas Blade con diseño responsivo y cohesivo
- ✅ Layout autenticado con sidebar, topbar y footer de usuario
- ✅ Layout público con portal de rastreo oscuro
- ✅ Integración de Toastr.js para notificaciones
- ✅ Protección de rutas por autenticación y por rol
- ✅ Eliminación lógica (SoftDeletes) con pantalla de restauración
- ✅ **[FIX]** Vista pública muestra nombre del estado + fecha explícitamente para cada status (En Proceso, En Ruta, Entregado)
- ✅ **[FIX]** `dashboard.blade.php` movido a `resources/views/dashboard.blade.php` (raíz correcta) y `DashboardController` apunta a `view('dashboard')`
