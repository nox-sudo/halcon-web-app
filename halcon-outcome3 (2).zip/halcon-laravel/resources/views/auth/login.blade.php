@extends('layouts.guest')

@section('title', 'Iniciar Sesión')

@push('styles')
<style>
    .login-wrap {
        min-height: calc(100vh - 88px);
        display: flex; align-items: center;
        justify-content: center; padding: 40px 20px;
        position: relative; z-index: 5;
    }
    .login-box {
        width: 100%; max-width: 400px;
    }
    .login-heading {
        text-align: center; margin-bottom: 32px;
    }
    .login-heading h1 { font-size: 1.8rem; font-weight: 800; }
    .login-heading p { color: rgba(255,255,255,.45); font-size: .9rem; margin-top: 6px; }

    .login-card {
        background: rgba(255,255,255,.06);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255,255,255,.1);
        border-radius: 16px; padding: 32px;
    }
    .field-group { margin-bottom: 20px; }
    .field-group label {
        display: block; font-size: .75rem; font-weight: 700;
        letter-spacing: 1px; text-transform: uppercase;
        color: rgba(255,255,255,.45); margin-bottom: 8px;
    }
    .field-group input {
        width: 100%; background: rgba(255,255,255,.08);
        border: 1.5px solid rgba(255,255,255,.12);
        border-radius: 10px; padding: 12px 16px;
        color: #fff; font-family: 'DM Sans', sans-serif;
        font-size: .95rem; outline: none;
        transition: border-color .2s;
    }
    .field-group input:focus { border-color: var(--brand-light); }
    .field-group input.error { border-color: #F87171; }
    .field-error { font-size: .75rem; color: #F87171; margin-top: 5px; }

    .btn-login {
        width: 100%; background: var(--brand); color: #fff;
        border: none; border-radius: 10px; padding: 13px;
        font-family: 'Syne', sans-serif; font-weight: 700;
        font-size: 1rem; cursor: pointer;
        transition: background .2s;
    }
    .btn-login:hover { background: var(--brand-dark); }

    .back-link {
        display: block; text-align: center; margin-top: 20px;
        color: rgba(255,255,255,.4); font-size: .85rem;
        text-decoration: none; transition: color .2s;
    }
    .back-link:hover { color: rgba(255,255,255,.7); }
</style>
@endpush

@section('content')
<div class="login-wrap">
    <div class="login-box">
        <div class="login-heading">
            <h1>Acceso Interno</h1>
            <p>Ingresa tus credenciales para continuar</p>
        </div>

        <div class="login-card">
            @if ($errors->any())
                <div style="background:rgba(239,68,68,.15);border:1px solid rgba(239,68,68,.3);border-radius:10px;padding:12px 16px;margin-bottom:20px;color:#FCA5A5;font-size:.85rem;">
                    <i class="fa-solid fa-circle-exclamation me-2"></i>
                    {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('login') }}">
                @csrf
                <div class="field-group">
                    <label>Correo electrónico</label>
                    <input type="email" name="email" value="{{ old('email') }}"
                           placeholder="empleado@halcon.mx"
                           class="{{ $errors->has('email') ? 'error' : '' }}" required>
                    @error('email') <div class="field-error">{{ $message }}</div> @enderror
                </div>

                <div class="field-group">
                    <label>Contraseña</label>
                    <input type="password" name="password" placeholder="••••••••"
                           class="{{ $errors->has('password') ? 'error' : '' }}" required>
                    @error('password') <div class="field-error">{{ $message }}</div> @enderror
                </div>

                <button type="submit" class="btn-login">
                    Ingresar al Sistema
                </button>
            </form>

            <a href="{{ route('home') }}" class="back-link">
                <i class="fa-solid fa-arrow-left me-1"></i> Volver al rastreo público
            </a>
        </div>
    </div>
</div>
@endsection
