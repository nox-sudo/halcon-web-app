@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')

{{-- STAT CARDS --}}
<div class="row g-3 mb-4">
    <div class="col-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon orange"><i class="fa-solid fa-box"></i></div>
            <div>
                <div class="stat-val">{{ $stats['ordered'] ?? 0 }}</div>
                <div class="stat-lbl">Pedidos Registrados</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon blue"><i class="fa-solid fa-gears"></i></div>
            <div>
                <div class="stat-val">{{ $stats['in_process'] ?? 0 }}</div>
                <div class="stat-lbl">En Proceso</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon amber"><i class="fa-solid fa-truck"></i></div>
            <div>
                <div class="stat-val">{{ $stats['in_route'] ?? 0 }}</div>
                <div class="stat-lbl">En Ruta</div>
            </div>
        </div>
    </div>
    <div class="col-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-icon green"><i class="fa-solid fa-circle-check"></i></div>
            <div>
                <div class="stat-val">{{ $stats['delivered'] ?? 0 }}</div>
                <div class="stat-lbl">Entregados</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    {{-- Recent Orders --}}
    <div class="col-lg-8">
        <div class="card-halcon">
            <div class="card-header-h">
                <i class="fa-solid fa-clock-rotate-left" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Pedidos Recientes</span>
                <a href="{{ route('orders.index') }}" class="ms-auto btn-outline-brand" style="font-size:.8rem;padding:6px 12px;">
                    Ver todos
                </a>
            </div>
            <div class="card-body-h p-0">
                <table class="table-halcon">
                    <thead>
                        <tr>
                            <th>Factura</th>
                            <th>Cliente</th>
                            <th>Fecha</th>
                            <th>Estado</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($recentOrders as $order)
                        <tr>
                            <td><span style="font-weight:600">{{ $order->invoice_number }}</span></td>
                            <td>{{ $order->customer_name }}</td>
                            <td style="color:var(--ink-soft);font-size:.82rem">
                                {{ $order->created_at->format('d M Y') }}
                            </td>
                            <td>
                                @php
                                    $badges = [
                                        'ordered'    => ['s-ordered',   'Pedido'],
                                        'in_process' => ['s-process',   'En Proceso'],
                                        'in_route'   => ['s-route',     'En Ruta'],
                                        'delivered'  => ['s-delivered', 'Entregado'],
                                    ];
                                    [$bc, $bl] = $badges[$order->status] ?? ['', $order->status];
                                @endphp
                                <span class="badge-status {{ $bc }}">{{ $bl }}</span>
                            </td>
                            <td>
                                <a href="{{ route('orders.show', $order) }}"
                                   style="color:var(--brand);font-size:.85rem;text-decoration:none;">
                                    <i class="fa-solid fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="5" style="text-align:center;color:var(--ink-soft);padding:32px">
                                No hay pedidos recientes.
                            </td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    {{-- Quick Links --}}
    <div class="col-lg-4">
        <div class="card-halcon h-100">
            <div class="card-header-h">
                <i class="fa-solid fa-bolt" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Acciones Rápidas</span>
            </div>
            <div class="card-body-h d-flex flex-column gap-2">
                @can('create', App\Models\Order::class)
                <a href="{{ route('orders.create') }}" class="btn-brand w-100 justify-content-center">
                    <i class="fa-solid fa-plus"></i> Nuevo Pedido
                </a>
                @endcan

                <a href="{{ route('orders.index') }}" class="btn-outline-brand w-100 justify-content-center">
                    <i class="fa-solid fa-list"></i> Todos los Pedidos
                </a>

                @role('admin')
                <a href="{{ route('users.create') }}" class="btn-outline-brand w-100 justify-content-center">
                    <i class="fa-solid fa-user-plus"></i> Nuevo Usuario
                </a>
                <a href="{{ route('users.index') }}" class="btn-outline-brand w-100 justify-content-center">
                    <i class="fa-solid fa-users"></i> Gestionar Usuarios
                </a>
                @endrole

                <a href="{{ route('orders.archived') }}" class="btn-outline-brand w-100 justify-content-center"
                   style="border-color:#9CA3AF;color:#6B7280;">
                    <i class="fa-solid fa-archive"></i> Pedidos Archivados
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
