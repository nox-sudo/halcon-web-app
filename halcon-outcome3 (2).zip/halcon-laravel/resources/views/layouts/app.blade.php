<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Halcón — @yield('title', 'Panel Administrativo')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --brand:       #D4500A;
            --brand-dark:  #A83B06;
            --brand-light: #F4793B;
            --ink:         #1A1612;
            --ink-soft:    #4A3F38;
            --surface:     #FAF8F6;
            --panel:       #FFFFFF;
            --border:      #EDE8E3;
            --sidebar-w:   260px;
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--surface);
            color: var(--ink);
            min-height: 100vh;
        }

        h1, h2, h3, h4, h5, .brand-font { font-family: 'Syne', sans-serif; }

        /* ── SIDEBAR ─────────────────────────────────── */
        .sidebar {
            position: fixed; top: 0; left: 0;
            width: var(--sidebar-w); height: 100vh;
            background: var(--ink);
            display: flex; flex-direction: column;
            z-index: 100;
            transition: transform .3s ease;
        }

        .sidebar-logo {
            padding: 28px 24px 20px;
            border-bottom: 1px solid rgba(255,255,255,.08);
        }

        .sidebar-logo .logo-mark {
            font-family: 'Syne', sans-serif;
            font-size: 1.5rem; font-weight: 800;
            color: #fff; letter-spacing: -.5px;
        }
        .sidebar-logo .logo-mark span { color: var(--brand-light); }
        .sidebar-logo .logo-sub {
            font-size: .7rem; color: rgba(255,255,255,.35);
            letter-spacing: 2px; text-transform: uppercase;
            margin-top: 2px;
        }

        .sidebar-nav { flex: 1; padding: 16px 0; overflow-y: auto; }

        .nav-section {
            font-size: .65rem; font-weight: 600; letter-spacing: 2px;
            text-transform: uppercase; color: rgba(255,255,255,.3);
            padding: 16px 24px 6px;
        }

        .sidebar-link {
            display: flex; align-items: center; gap: 12px;
            padding: 10px 24px; color: rgba(255,255,255,.6);
            text-decoration: none; font-size: .875rem;
            transition: all .2s;
            border-left: 3px solid transparent;
        }
        .sidebar-link i { width: 18px; text-align: center; font-size: .9rem; }
        .sidebar-link:hover {
            color: #fff; background: rgba(255,255,255,.05);
            border-left-color: var(--brand-light);
        }
        .sidebar-link.active {
            color: #fff; background: rgba(212,80,10,.15);
            border-left-color: var(--brand);
        }

        .sidebar-footer {
            padding: 16px 24px;
            border-top: 1px solid rgba(255,255,255,.08);
        }
        .user-pill {
            display: flex; align-items: center; gap: 10px;
        }
        .user-avatar {
            width: 36px; height: 36px; border-radius: 50%;
            background: var(--brand); display: flex; align-items: center;
            justify-content: center; font-family: 'Syne', sans-serif;
            font-weight: 700; color: #fff; font-size: .85rem;
            flex-shrink: 0;
        }
        .user-info .user-name { font-size: .85rem; color: #fff; font-weight: 500; }
        .user-info .user-role { font-size: .7rem; color: rgba(255,255,255,.4); }
        .logout-btn {
            margin-left: auto; color: rgba(255,255,255,.3);
            background: none; border: none; cursor: pointer;
            font-size: 1rem; transition: color .2s;
        }
        .logout-btn:hover { color: var(--brand-light); }

        /* ── TOPBAR ──────────────────────────────────── */
        .topbar {
            position: fixed; top: 0;
            left: var(--sidebar-w); right: 0;
            height: 64px; background: var(--panel);
            border-bottom: 1px solid var(--border);
            display: flex; align-items: center;
            padding: 0 32px; z-index: 90;
            gap: 16px;
        }
        .topbar-title {
            font-family: 'Syne', sans-serif;
            font-size: 1.1rem; font-weight: 700; color: var(--ink);
        }
        .topbar-right { margin-left: auto; display: flex; align-items: center; gap: 12px; }

        /* ── MAIN CONTENT ────────────────────────────── */
        .main-content {
            margin-left: var(--sidebar-w);
            padding-top: 64px;
            min-height: 100vh;
        }
        .page-body { padding: 32px; }

        /* ── CARDS ───────────────────────────────────── */
        .card-halcon {
            background: var(--panel);
            border: 1px solid var(--border);
            border-radius: 12px;
            box-shadow: 0 1px 4px rgba(0,0,0,.04);
        }
        .card-halcon .card-header-h {
            padding: 20px 24px 16px;
            border-bottom: 1px solid var(--border);
            display: flex; align-items: center; gap: 12px;
        }
        .card-halcon .card-body-h { padding: 24px; }

        /* ── STAT CARDS ──────────────────────────────── */
        .stat-card {
            background: var(--panel);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 20px 24px;
            display: flex; align-items: center; gap: 16px;
        }
        .stat-icon {
            width: 48px; height: 48px; border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 1.25rem;
        }
        .stat-icon.orange { background: rgba(212,80,10,.1); color: var(--brand); }
        .stat-icon.blue   { background: rgba(59,130,246,.1); color: #3B82F6; }
        .stat-icon.green  { background: rgba(16,185,129,.1); color: #10B981; }
        .stat-icon.amber  { background: rgba(245,158,11,.1); color: #F59E0B; }

        .stat-val { font-family: 'Syne', sans-serif; font-size: 1.8rem; font-weight: 800; }
        .stat-lbl { font-size: .8rem; color: var(--ink-soft); }

        /* ── BADGES / STATUS ─────────────────────────── */
        .badge-status {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 10px; border-radius: 20px;
            font-size: .75rem; font-weight: 600;
        }
        .badge-status::before {
            content: ''; width: 6px; height: 6px; border-radius: 50%;
            background: currentColor;
        }
        .s-ordered   { background: #FEF3C7; color: #92400E; }
        .s-process   { background: #DBEAFE; color: #1D4ED8; }
        .s-route     { background: #FCE7F3; color: #9D174D; }
        .s-delivered { background: #D1FAE5; color: #065F46; }
        .s-deleted   { background: #F3F4F6; color: #6B7280; }

        /* ── BUTTONS ─────────────────────────────────── */
        .btn-brand {
            background: var(--brand); color: #fff;
            border: none; border-radius: 8px;
            padding: 9px 18px; font-family: 'Syne', sans-serif;
            font-weight: 600; font-size: .875rem;
            cursor: pointer; transition: background .2s;
            text-decoration: none; display: inline-flex;
            align-items: center; gap: 8px;
        }
        .btn-brand:hover { background: var(--brand-dark); color: #fff; }

        .btn-outline-brand {
            background: transparent; color: var(--brand);
            border: 1.5px solid var(--brand); border-radius: 8px;
            padding: 8px 16px; font-family: 'Syne', sans-serif;
            font-weight: 600; font-size: .875rem;
            cursor: pointer; transition: all .2s;
            text-decoration: none; display: inline-flex;
            align-items: center; gap: 8px;
        }
        .btn-outline-brand:hover { background: var(--brand); color: #fff; }

        /* ── TABLES ──────────────────────────────────── */
        .table-halcon { width: 100%; border-collapse: collapse; }
        .table-halcon th {
            font-family: 'Syne', sans-serif; font-size: .75rem;
            font-weight: 700; letter-spacing: 1px; text-transform: uppercase;
            color: var(--ink-soft); padding: 12px 16px;
            border-bottom: 2px solid var(--border); text-align: left;
        }
        .table-halcon td {
            padding: 14px 16px; border-bottom: 1px solid var(--border);
            font-size: .875rem; vertical-align: middle;
        }
        .table-halcon tr:hover td { background: #FBF9F7; }
        .table-halcon tr:last-child td { border-bottom: none; }

        /* ── FORMS ───────────────────────────────────── */
        .form-label-h {
            font-family: 'Syne', sans-serif; font-size: .8rem;
            font-weight: 700; letter-spacing: .5px; color: var(--ink);
            margin-bottom: 6px; display: block;
        }
        .form-control-h {
            width: 100%; padding: 10px 14px;
            border: 1.5px solid var(--border); border-radius: 8px;
            font-family: 'DM Sans', sans-serif; font-size: .875rem;
            color: var(--ink); background: var(--surface);
            transition: border-color .2s;
            outline: none;
        }
        .form-control-h:focus { border-color: var(--brand); background: #fff; }
        .form-control-h.is-invalid { border-color: #EF4444; }

        /* ── PAGE HEADER ─────────────────────────────── */
        .page-header {
            display: flex; align-items: center; justify-content: space-between;
            margin-bottom: 28px;
        }
        .page-header h1 {
            font-size: 1.6rem; font-weight: 800; color: var(--ink);
        }
        .page-header .breadcrumb-h {
            font-size: .8rem; color: var(--ink-soft); margin-top: 2px;
        }

        /* ── ALERTS ──────────────────────────────────── */
        #toast-container > div {
            border-radius: 10px !important;
            box-shadow: 0 4px 24px rgba(0,0,0,.12) !important;
        }

        /* Toastr overrides */
        .toast-success { background-color: #065F46 !important; }
        .toast-error   { background-color: #9B1C1C !important; }
        .toast-info    { background-color: #1E40AF !important; }
        .toast-warning { background-color: #92400E !important; }

        @media (max-width: 768px) {
            .sidebar { transform: translateX(-100%); }
            .sidebar.open { transform: translateX(0); }
            .main-content { margin-left: 0; }
            .topbar { left: 0; }
        }
    </style>
    @stack('styles')
</head>
<body>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
    <div class="sidebar-logo">
        <div class="logo-mark">HAL<span>CÓN</span></div>
        <div class="logo-sub">Distribuidora</div>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section">Principal</div>
        <a href="{{ route('dashboard') }}" class="sidebar-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
            <i class="fa-solid fa-gauge-high"></i> Dashboard
        </a>

        <div class="nav-section">Pedidos</div>
        <a href="{{ route('orders.index') }}" class="sidebar-link {{ request()->routeIs('orders.*') && !request()->routeIs('orders.archived') ? 'active' : '' }}">
            <i class="fa-solid fa-box"></i> Todos los Pedidos
        </a>
        @can('create', App\Models\Order::class)
        <a href="{{ route('orders.create') }}" class="sidebar-link {{ request()->routeIs('orders.create') ? 'active' : '' }}">
            <i class="fa-solid fa-plus-circle"></i> Nuevo Pedido
        </a>
        @endcan
        <a href="{{ route('orders.archived') }}" class="sidebar-link {{ request()->routeIs('orders.archived') ? 'active' : '' }}">
            <i class="fa-solid fa-archive"></i> Archivados
        </a>

        @role('admin')
        <div class="nav-section">Administración</div>
        <a href="{{ route('users.index') }}" class="sidebar-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
            <i class="fa-solid fa-users"></i> Usuarios
        </a>
        @endrole
    </nav>

    <div class="sidebar-footer">
        <div class="user-pill">
            <div class="user-avatar">{{ strtoupper(substr(auth()->user()->name, 0, 2)) }}</div>
            <div class="user-info">
                <div class="user-name">{{ auth()->user()->name }}</div>
                <div class="user-role">{{ auth()->user()->role->name ?? 'Admin' }}</div>
            </div>
            <form method="POST" action="{{ route('logout') }}">
                @csrf
                <button type="submit" class="logout-btn" title="Cerrar sesión">
                    <i class="fa-solid fa-arrow-right-from-bracket"></i>
                </button>
            </form>
        </div>
    </div>
</aside>

<!-- TOPBAR -->
<header class="topbar">
    <button class="d-md-none" style="background:none;border:none;font-size:1.2rem;" onclick="document.getElementById('sidebar').classList.toggle('open')">
        <i class="fa-solid fa-bars"></i>
    </button>
    <span class="topbar-title">@yield('page-title', 'Dashboard')</span>
    <div class="topbar-right">
        <span style="font-size:.8rem;color:var(--ink-soft);">
            <i class="fa-regular fa-clock"></i>
            {{ now()->format('d M Y') }}
        </span>
    </div>
</header>

<!-- MAIN -->
<main class="main-content">
    <div class="page-body">
        @yield('content')
    </div>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
    toastr.options = {
        closeButton: true,
        progressBar: true,
        positionClass: 'toast-top-right',
        timeOut: 4000,
    };
    @if(session('success')) toastr.success("{{ session('success') }}"); @endif
    @if(session('error'))   toastr.error("{{ session('error') }}");     @endif
    @if(session('info'))    toastr.info("{{ session('info') }}");       @endif
    @if(session('warning')) toastr.warning("{{ session('warning') }}"); @endif
</script>
@stack('scripts')
</body>
</html>
