<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halcón — @yield('title', 'Rastreo de Pedido')</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <style>
        :root {
            --brand: #D4500A;
            --brand-dark: #A83B06;
            --brand-light: #F4793B;
            --ink: #1A1612;
            --surface: #FAF8F6;
        }
        * { box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--ink);
            color: #fff;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed; inset: 0;
            background:
                radial-gradient(ellipse 60% 50% at 80% 20%, rgba(212,80,10,.25) 0%, transparent 60%),
                radial-gradient(ellipse 40% 60% at 10% 80%, rgba(168,59,6,.2) 0%, transparent 60%);
            pointer-events: none;
        }
        h1,h2,h3 { font-family: 'Syne', sans-serif; }
        .nav-pub {
            padding: 24px 40px;
            display: flex; align-items: center; justify-content: space-between;
            position: relative; z-index: 10;
        }
        .logo-mark {
            font-family: 'Syne', sans-serif; font-size: 1.4rem;
            font-weight: 800; color: #fff; letter-spacing: -.5px;
        }
        .logo-mark span { color: var(--brand-light); }
        .nav-login {
            color: rgba(255,255,255,.6); text-decoration: none;
            font-size: .875rem; transition: color .2s;
        }
        .nav-login:hover { color: #fff; }

        @yield('styles')
    </style>
    @stack('styles')
</head>
<body>
    <nav class="nav-pub">
        <div class="logo-mark">HAL<span>CÓN</span></div>
        <a href="{{ route('login') }}" class="nav-login">
            <i class="fa-solid fa-lock me-1"></i> Acceso Empleados
        </a>
    </nav>

    @yield('content')

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
