@extends('layouts.app')

@section('title', 'Pedidos Archivados')
@section('page-title', 'Pedidos Archivados')

@section('content')
<div class="page-header">
    <div>
        <h1>Pedidos Archivados</h1>
        <div class="breadcrumb-h">Pedidos eliminados lógicamente — pueden ser restaurados</div>
    </div>
    <a href="{{ route('orders.index') }}" class="btn-outline-brand">
        <i class="fa-solid fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card-halcon">
    <div class="card-body-h p-0">
        <table class="table-halcon">
            <thead>
                <tr>
                    <th>Factura</th>
                    <th>N° Cliente</th>
                    <th>Cliente</th>
                    <th>Fecha Pedido</th>
                    <th>Archivado</th>
                    <th>Estado</th>
                    <th style="text-align:right">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $order)
                <tr style="opacity:.7">
                    <td><strong>{{ $order->invoice_number }}</strong></td>
                    <td style="color:var(--ink-soft)">{{ $order->customer_number }}</td>
                    <td>{{ $order->customer_name }}</td>
                    <td style="font-size:.82rem;color:var(--ink-soft)">{{ $order->created_at->format('d M Y') }}</td>
                    <td style="font-size:.82rem;color:var(--ink-soft)">{{ $order->deleted_at->format('d M Y') }}</td>
                    <td>
                        <span class="badge-status s-deleted">Archivado</span>
                    </td>
                    <td>
                        <div class="d-flex gap-2 justify-content-end">
                            <a href="{{ route('orders.show', $order) }}"
                               class="btn-outline-brand" style="padding:6px 10px;font-size:.8rem;" title="Ver">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            <form method="POST" action="{{ route('orders.restore', $order) }}">
                                @csrf @method('PATCH')
                                <button type="submit"
                                    style="background:none;border:1.5px solid #10B981;border-radius:8px;padding:6px 10px;color:#10B981;cursor:pointer;font-size:.8rem;transition:all .2s;"
                                    title="Restaurar"
                                    onmouseover="this.style.background='#10B981';this.style.color='#fff'"
                                    onmouseout="this.style.background='none';this.style.color='#10B981'">
                                    <i class="fa-solid fa-rotate-left"></i>
                                </button>
                            </form>
                            <a href="{{ route('orders.edit', $order) }}"
                               class="btn-outline-brand" style="padding:6px 10px;font-size:.8rem;" title="Editar">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center;padding:48px;color:var(--ink-soft)">
                        <i class="fa-solid fa-archive fa-2x mb-3 d-block" style="opacity:.3"></i>
                        No hay pedidos archivados.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($orders->hasPages())
    <div style="padding:16px 24px;border-top:1px solid var(--border)">
        {{ $orders->withQueryString()->links() }}
    </div>
    @endif
</div>
@endsection
