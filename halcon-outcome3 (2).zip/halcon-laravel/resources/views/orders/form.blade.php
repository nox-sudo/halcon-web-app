@extends('layouts.app')

@section('title', isset($order) ? 'Editar Pedido' : 'Nuevo Pedido')
@section('page-title', isset($order) ? 'Editar Pedido' : 'Nuevo Pedido')

@section('content')
<div class="page-header">
    <div>
        <h1>{{ isset($order) ? 'Editar Pedido' : 'Registrar Nuevo Pedido' }}</h1>
        <div class="breadcrumb-h">
            <a href="{{ route('orders.index') }}" style="color:var(--brand);text-decoration:none">Pedidos</a>
            &rsaquo; {{ isset($order) ? $order->invoice_number : 'Nuevo' }}
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card-halcon">
            <div class="card-header-h">
                <i class="fa-solid fa-file-invoice" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Datos del Pedido</span>
            </div>
            <div class="card-body-h">
                <form method="POST"
                      action="{{ isset($order) ? route('orders.update', $order) : route('orders.store') }}"
                      enctype="multipart/form-data">
                    @csrf
                    @if(isset($order)) @method('PUT') @endif

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label-h">N° Factura *</label>
                            <input type="text" name="invoice_number" class="form-control-h {{ $errors->has('invoice_number') ? 'is-invalid' : '' }}"
                                   value="{{ old('invoice_number', $order->invoice_number ?? '') }}"
                                   placeholder="FAC-2024-001" required>
                            @error('invoice_number')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label-h">N° Cliente *</label>
                            <input type="text" name="customer_number" class="form-control-h {{ $errors->has('customer_number') ? 'is-invalid' : '' }}"
                                   value="{{ old('customer_number', $order->customer_number ?? '') }}"
                                   placeholder="CLI-0042" required>
                            @error('customer_number')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-12">
                            <label class="form-label-h">Nombre / Razón Social *</label>
                            <input type="text" name="customer_name" class="form-control-h {{ $errors->has('customer_name') ? 'is-invalid' : '' }}"
                                   value="{{ old('customer_name', $order->customer_name ?? '') }}"
                                   placeholder="Constructora Ejemplo S.A. de C.V." required>
                        </div>

                        <div class="col-12">
                            <label class="form-label-h">Domicilio de Entrega *</label>
                            <input type="text" name="delivery_address" class="form-control-h"
                                   value="{{ old('delivery_address', $order->delivery_address ?? '') }}"
                                   placeholder="Calle, Número, Colonia, Ciudad" required>
                        </div>

                        {{-- Datos Fiscales --}}
                        <div class="col-12">
                            <div style="font-family:'Syne',sans-serif;font-size:.8rem;font-weight:700;letter-spacing:1px;text-transform:uppercase;color:var(--ink-soft);padding:8px 0 4px;border-top:1px solid var(--border);margin-top:8px">
                                Datos Fiscales
                            </div>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label-h">RFC</label>
                            <input type="text" name="rfc" class="form-control-h"
                                   value="{{ old('rfc', $order->rfc ?? '') }}"
                                   placeholder="CONS800101ABC">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label-h">Régimen Fiscal</label>
                            <input type="text" name="fiscal_regime" class="form-control-h"
                                   value="{{ old('fiscal_regime', $order->fiscal_regime ?? '') }}"
                                   placeholder="Persona Moral">
                        </div>
                        <div class="col-12">
                            <label class="form-label-h">Domicilio Fiscal</label>
                            <input type="text" name="fiscal_address" class="form-control-h"
                                   value="{{ old('fiscal_address', $order->fiscal_address ?? '') }}"
                                   placeholder="Calle, Número, Colonia, CP, Ciudad">
                        </div>

                        {{-- Notes --}}
                        <div class="col-12" style="margin-top:8px">
                            <label class="form-label-h">Notas / Observaciones</label>
                            <textarea name="notes" class="form-control-h" rows="3"
                                      placeholder="Información adicional sobre el pedido...">{{ old('notes', $order->notes ?? '') }}</textarea>
                        </div>

                        <div class="col-12 d-flex gap-2 justify-content-end" style="margin-top:8px">
                            <a href="{{ route('orders.index') }}" class="btn-outline-brand">
                                Cancelar
                            </a>
                            <button type="submit" class="btn-brand">
                                <i class="fa-solid fa-floppy-disk"></i>
                                {{ isset($order) ? 'Guardar Cambios' : 'Registrar Pedido' }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    {{-- Sidebar info --}}
    <div class="col-lg-4">
        <div class="card-halcon">
            <div class="card-header-h">
                <i class="fa-solid fa-circle-info" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Información</span>
            </div>
            <div class="card-body-h">
                <div style="font-size:.85rem;color:var(--ink-soft);line-height:1.7">
                    @if(isset($order))
                        <div class="mb-3">
                            <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--ink-soft);font-weight:700">Estado actual</div>
                            @php
                                $badges = ['ordered'=>['s-ordered','Pedido'],'in_process'=>['s-process','En Proceso'],'in_route'=>['s-route','En Ruta'],'delivered'=>['s-delivered','Entregado']];
                                [$bc,$bl] = $badges[$order->status] ?? ['',''];
                            @endphp
                            <span class="badge-status {{ $bc }} mt-1">{{ $bl }}</span>
                        </div>
                        <div class="mb-3">
                            <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--ink-soft);font-weight:700">Registrado por</div>
                            <div style="color:var(--ink)">{{ $order->creator->name ?? '—' }}</div>
                        </div>
                        <div>
                            <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--ink-soft);font-weight:700">Fecha de creación</div>
                            <div style="color:var(--ink)">{{ $order->created_at->format('d M Y H:i') }}</div>
                        </div>
                    @else
                        <p>• El número de factura debe ser único y consecutivo.</p>
                        <p>• El número de cliente es asignado arbitrariamente.</p>
                        <p>• El estado inicial será <strong>Pedido Registrado</strong>.</p>
                        <p>• El pedido quedará visible para todos los empleados al guardarse.</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
