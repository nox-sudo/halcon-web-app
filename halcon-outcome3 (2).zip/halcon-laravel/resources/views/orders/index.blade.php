@extends('layouts.app')

@section('title', 'Pedidos')
@section('page-title', 'Gestión de Pedidos')

@section('content')
<div class="page-header">
    <div>
        <h1>Pedidos</h1>
        <div class="breadcrumb-h">Lista general de pedidos activos</div>
    </div>
    @can('create', App\Models\Order::class)
    <a href="{{ route('orders.create') }}" class="btn-brand">
        <i class="fa-solid fa-plus"></i> Nuevo Pedido
    </a>
    @endcan
</div>

{{-- FILTERS --}}
<div class="card-halcon mb-4">
    <div class="card-body-h">
        <form method="GET" action="{{ route('orders.index') }}" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label-h">N° Factura</label>
                <input type="text" name="factura" class="form-control-h"
                       placeholder="FAC-2024-001" value="{{ request('factura') }}">
            </div>
            <div class="col-md-3">
                <label class="form-label-h">N° Cliente</label>
                <input type="text" name="cliente" class="form-control-h"
                       placeholder="CLI-0042" value="{{ request('cliente') }}">
            </div>
            <div class="col-md-2">
                <label class="form-label-h">Fecha</label>
                <input type="date" name="fecha" class="form-control-h" value="{{ request('fecha') }}">
            </div>
            <div class="col-md-2">
                <label class="form-label-h">Estado</label>
                <select name="status" class="form-control-h">
                    <option value="">Todos</option>
                    <option value="ordered"    {{ request('status') === 'ordered'    ? 'selected' : '' }}>Pedido</option>
                    <option value="in_process" {{ request('status') === 'in_process' ? 'selected' : '' }}>En Proceso</option>
                    <option value="in_route"   {{ request('status') === 'in_route'   ? 'selected' : '' }}>En Ruta</option>
                    <option value="delivered"  {{ request('status') === 'delivered'  ? 'selected' : '' }}>Entregado</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn-brand flex-fill">
                    <i class="fa-solid fa-filter"></i> Filtrar
                </button>
                <a href="{{ route('orders.index') }}" class="btn-outline-brand" title="Limpiar">
                    <i class="fa-solid fa-xmark"></i>
                </a>
            </div>
        </form>
    </div>
</div>

{{-- TABLE --}}
<div class="card-halcon">
    <div class="card-body-h p-0">
        <table class="table-halcon">
            <thead>
                <tr>
                    <th>Factura</th>
                    <th>N° Cliente</th>
                    <th>Cliente</th>
                    <th>Fecha</th>
                    <th>Dirección</th>
                    <th>Estado</th>
                    <th style="text-align:right">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @forelse($orders as $order)
                <tr>
                    <td><strong>{{ $order->invoice_number }}</strong></td>
                    <td style="color:var(--ink-soft)">{{ $order->customer_number }}</td>
                    <td>{{ $order->customer_name }}</td>
                    <td style="font-size:.82rem;color:var(--ink-soft)">
                        {{ $order->created_at->format('d M Y') }}<br>
                        <span style="font-size:.75rem">{{ $order->created_at->format('H:i') }}</span>
                    </td>
                    <td style="font-size:.82rem;max-width:180px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                        {{ $order->delivery_address }}
                    </td>
                    <td>
                        @php
                            $badges = [
                                'ordered'    => ['s-ordered',   'Pedido'],
                                'in_process' => ['s-process',   'En Proceso'],
                                'in_route'   => ['s-route',     'En Ruta'],
                                'delivered'  => ['s-delivered', 'Entregado'],
                            ];
                            [$bc, $bl] = $badges[$order->status] ?? ['', $order->status];
                        @endphp
                        <span class="badge-status {{ $bc }}">{{ $bl }}</span>
                    </td>
                    <td>
                        <div class="d-flex gap-2 justify-content-end">
                            <a href="{{ route('orders.show', $order) }}"
                               class="btn-outline-brand" style="padding:6px 10px;font-size:.8rem;" title="Ver">
                                <i class="fa-solid fa-eye"></i>
                            </a>
                            @can('update', $order)
                            <a href="{{ route('orders.edit', $order) }}"
                               class="btn-outline-brand" style="padding:6px 10px;font-size:.8rem;" title="Editar">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            @endcan
                            @can('delete', $order)
                            <form method="POST" action="{{ route('orders.destroy', $order) }}"
                                  onsubmit="return confirm('¿Archivar este pedido?')">
                                @csrf @method('DELETE')
                                <button type="submit"
                                    style="background:none;border:1.5px solid #EF4444;border-radius:8px;padding:6px 10px;color:#EF4444;cursor:pointer;font-size:.8rem;transition:all .2s;"
                                    title="Archivar"
                                    onmouseover="this.style.background='#EF4444';this.style.color='#fff'"
                                    onmouseout="this.style.background='none';this.style.color='#EF4444'">
                                    <i class="fa-solid fa-archive"></i>
                                </button>
                            </form>
                            @endcan
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="7" style="text-align:center;padding:48px;color:var(--ink-soft)">
                        <i class="fa-solid fa-box-open fa-2x mb-3 d-block" style="opacity:.3"></i>
                        No se encontraron pedidos.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>

    @if($orders->hasPages())
    <div style="padding:16px 24px;border-top:1px solid var(--border)">
        {{ $orders->withQueryString()->links() }}
    </div>
    @endif
</div>
@endsection
