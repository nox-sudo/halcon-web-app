@extends('layouts.app')

@section('title', 'Pedido ' . $order->invoice_number)
@section('page-title', 'Detalle de Pedido')

@section('content')
<div class="page-header">
    <div>
        <h1>{{ $order->invoice_number }}</h1>
        <div class="breadcrumb-h">
            <a href="{{ route('orders.index') }}" style="color:var(--brand);text-decoration:none">Pedidos</a>
            &rsaquo; {{ $order->invoice_number }}
        </div>
    </div>
    <div class="d-flex gap-2">
        @can('update', $order)
        <a href="{{ route('orders.edit', $order) }}" class="btn-outline-brand">
            <i class="fa-solid fa-pen"></i> Editar
        </a>
        @endcan
        @can('delete', $order)
        <form method="POST" action="{{ route('orders.destroy', $order) }}"
              onsubmit="return confirm('¿Deseas archivar este pedido?')">
            @csrf @method('DELETE')
            <button type="submit" style="background:none;border:1.5px solid #EF4444;border-radius:8px;padding:8px 16px;color:#EF4444;cursor:pointer;font-family:'Syne',sans-serif;font-size:.875rem;font-weight:600;display:flex;align-items:center;gap:8px;">
                <i class="fa-solid fa-archive"></i> Archivar
            </button>
        </form>
        @endcan
    </div>
</div>

<div class="row g-3">
    {{-- Order Details --}}
    <div class="col-lg-8">
        <div class="card-halcon mb-3">
            <div class="card-header-h">
                <i class="fa-solid fa-file-invoice" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Información del Pedido</span>
            </div>
            <div class="card-body-h">
                <div class="row g-3">
                    @php
                        $fields = [
                            ['N° Factura', $order->invoice_number],
                            ['N° Cliente', $order->customer_number],
                            ['Cliente', $order->customer_name],
                            ['Dirección de Entrega', $order->delivery_address],
                            ['RFC', $order->rfc ?: '—'],
                            ['Régimen Fiscal', $order->fiscal_regime ?: '—'],
                            ['Domicilio Fiscal', $order->fiscal_address ?: '—'],
                            ['Fecha del Pedido', $order->created_at->format('d M Y H:i')],
                            ['Registrado por', $order->creator->name ?? '—'],
                        ];
                    @endphp
                    @foreach($fields as [$label, $val])
                    <div class="col-md-6">
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;color:var(--ink-soft);margin-bottom:3px">{{ $label }}</div>
                        <div style="font-size:.9rem;color:var(--ink)">{{ $val }}</div>
                    </div>
                    @endforeach

                    @if($order->notes)
                    <div class="col-12">
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;color:var(--ink-soft);margin-bottom:3px">Notas</div>
                        <div style="font-size:.9rem;background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:12px">{{ $order->notes }}</div>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        {{-- Photos --}}
        @if($order->route_photo || $order->delivery_photo)
        <div class="card-halcon mb-3">
            <div class="card-header-h">
                <i class="fa-solid fa-camera" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Evidencias Fotográficas</span>
            </div>
            <div class="card-body-h">
                <div class="row g-3">
                    @if($order->route_photo)
                    <div class="col-md-6">
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;color:var(--ink-soft);margin-bottom:8px">
                            Foto de Carga (En Ruta)
                        </div>
                        <div style="border-radius:10px;overflow:hidden;border:1px solid var(--border)">
                            <img src="{{ Storage::url($order->route_photo) }}" alt="Foto de carga" style="width:100%;display:block">
                        </div>
                    </div>
                    @endif
                    @if($order->delivery_photo)
                    <div class="col-md-6">
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;font-weight:700;color:var(--ink-soft);margin-bottom:8px">
                            Foto de Entrega
                        </div>
                        <div style="border-radius:10px;overflow:hidden;border:1px solid var(--border)">
                            <img src="{{ Storage::url($order->delivery_photo) }}" alt="Evidencia de entrega" style="width:100%;display:block">
                        </div>
                    </div>
                    @endif
                </div>
            </div>
        </div>
        @endif
    </div>

    {{-- Sidebar: Status & Actions --}}
    <div class="col-lg-4">

        {{-- Current Status --}}
        <div class="card-halcon mb-3">
            <div class="card-header-h">
                <i class="fa-solid fa-signal" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Estado del Pedido</span>
            </div>
            <div class="card-body-h">
                @php
                    $badges = [
                        'ordered'    => ['s-ordered',   'Pedido Registrado'],
                        'in_process' => ['s-process',   'En Proceso'],
                        'in_route'   => ['s-route',     'En Ruta'],
                        'delivered'  => ['s-delivered', 'Entregado'],
                    ];
                    [$bc, $bl] = $badges[$order->status] ?? ['', $order->status];
                    $nextStatus = [
                        'ordered'    => 'in_process',
                        'in_process' => 'in_route',
                        'in_route'   => 'delivered',
                    ];
                    $nextLabels = [
                        'in_process' => 'Marcar En Proceso',
                        'in_route'   => 'Marcar En Ruta',
                        'delivered'  => 'Marcar Entregado',
                    ];
                @endphp

                <div class="mb-3">
                    <span class="badge-status {{ $bc }}" style="font-size:.9rem;padding:8px 14px">{{ $bl }}</span>
                </div>

                {{-- Status Timeline --}}
                @php $statuses = ['ordered','in_process','in_route','delivered']; @endphp
                <div style="margin-bottom:16px">
                    @foreach($statuses as $i => $s)
                        @php
                            $idx  = array_search($order->status, $statuses);
                            $done = $i <= $idx;
                            $cur  = $i === $idx;
                        @endphp
                        <div style="display:flex;align-items:center;gap:10px;margin-bottom:{{ $i < 3 ? '4px' : '0' }}">
                            <div style="width:28px;height:28px;border-radius:50%;background:{{ $done ? 'var(--brand)' : 'var(--border)' }};display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.7rem;color:{{ $done ? '#fff' : 'var(--ink-soft)' }};font-weight:700">
                                @if($done) <i class="fa-solid fa-check"></i> @else {{ $i+1 }} @endif
                            </div>
                            <div style="font-size:.82rem;font-weight:{{ $cur ? '700' : '400' }};color:{{ $done ? 'var(--ink)' : 'var(--ink-soft)' }}">
                                {{ $badges[$s][1] }}
                            </div>
                            @if($i < 3)
                            {{-- connector line --}}
                            @endif
                        </div>
                        @if($i < 3)
                        <div style="width:2px;height:12px;background:{{ $i < $idx ? 'var(--brand)' : 'var(--border)' }};margin-left:13px;margin-bottom:4px"></div>
                        @endif
                    @endforeach
                </div>

                {{-- Change Status Button --}}
                @can('changeStatus', $order)
                @if(isset($nextStatus[$order->status]))
                    @php $next = $nextStatus[$order->status]; @endphp
                    <form method="POST" action="{{ route('orders.status', $order) }}">
                        @csrf @method('PATCH')
                        <input type="hidden" name="status" value="{{ $next }}">
                        <button type="submit" class="btn-brand w-100 justify-content-center">
                            <i class="fa-solid fa-arrow-right"></i>
                            {{ $nextLabels[$next] }}
                        </button>
                    </form>
                @endif
                @endcan
            </div>
        </div>

        {{-- Photo Upload (Route department only) --}}
        @role('route')
        @if(in_array($order->status, ['in_route', 'delivered']) || $order->status === 'in_process')
        <div class="card-halcon mb-3">
            <div class="card-header-h">
                <i class="fa-solid fa-camera" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Subir Fotografía</span>
            </div>
            <div class="card-body-h">
                <form method="POST" action="{{ route('orders.photo', $order) }}"
                      enctype="multipart/form-data">
                    @csrf @method('PATCH')
                    <div class="mb-3">
                        <label class="form-label-h">
                            @if($order->status === 'in_route') Foto de Unidad Cargada
                            @else Foto de Entrega (Evidencia)
                            @endif
                        </label>
                        <input type="file" name="photo" class="form-control-h" accept="image/*" required
                               style="padding:8px 12px;cursor:pointer">
                        <div style="font-size:.75rem;color:var(--ink-soft);margin-top:5px">
                            JPG, PNG o WEBP. Máx. 5MB.
                        </div>
                    </div>
                    <input type="hidden" name="photo_type"
                           value="{{ $order->status === 'in_route' ? 'route' : 'delivery' }}">
                    <button type="submit" class="btn-brand w-100 justify-content-center">
                        <i class="fa-solid fa-upload"></i> Subir Foto
                    </button>
                </form>
            </div>
        </div>
        @endif
        @endrole
    </div>
</div>
@endsection
