@extends('layouts.app')

@section('title', isset($user) ? 'Editar Usuario' : 'Nuevo Usuario')
@section('page-title', isset($user) ? 'Editar Usuario' : 'Nuevo Usuario')

@section('content')
<div class="page-header">
    <div>
        <h1>{{ isset($user) ? 'Editar Usuario' : 'Registrar Usuario' }}</h1>
        <div class="breadcrumb-h">
            <a href="{{ route('users.index') }}" style="color:var(--brand);text-decoration:none">Usuarios</a>
            &rsaquo; {{ isset($user) ? $user->name : 'Nuevo' }}
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-7">
        <div class="card-halcon">
            <div class="card-header-h">
                <i class="fa-solid fa-user-gear" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Datos del Usuario</span>
            </div>
            <div class="card-body-h">
                <form method="POST"
                      action="{{ isset($user) ? route('users.update', $user) : route('users.store') }}">
                    @csrf
                    @if(isset($user)) @method('PUT') @endif

                    <div class="row g-3">
                        <div class="col-12">
                            <label class="form-label-h">Nombre Completo *</label>
                            <input type="text" name="name" class="form-control-h {{ $errors->has('name') ? 'is-invalid' : '' }}"
                                   value="{{ old('name', $user->name ?? '') }}"
                                   placeholder="Juan García López" required>
                            @error('name')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-h">Correo Electrónico *</label>
                            <input type="email" name="email" class="form-control-h {{ $errors->has('email') ? 'is-invalid' : '' }}"
                                   value="{{ old('email', $user->email ?? '') }}"
                                   placeholder="juan@halcon.mx" required>
                            @error('email')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-h">Departamento / Rol *</label>
                            <select name="role_id" class="form-control-h {{ $errors->has('role_id') ? 'is-invalid' : '' }}" required>
                                <option value="">Seleccionar departamento…</option>
                                @foreach($roles as $role)
                                    <option value="{{ $role->id }}"
                                        {{ old('role_id', $user->role_id ?? '') == $role->id ? 'selected' : '' }}>
                                        {{ $role->name }}
                                    </option>
                                @endforeach
                            </select>
                            @error('role_id')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-h">Contraseña {{ isset($user) ? '(dejar vacío para no cambiar)' : '*' }}</label>
                            <input type="password" name="password" class="form-control-h {{ $errors->has('password') ? 'is-invalid' : '' }}"
                                   placeholder="Mínimo 8 caracteres"
                                   {{ isset($user) ? '' : 'required' }}>
                            @error('password')
                                <div style="font-size:.75rem;color:#EF4444;margin-top:5px">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-6">
                            <label class="form-label-h">Confirmar Contraseña</label>
                            <input type="password" name="password_confirmation" class="form-control-h"
                                   placeholder="Repetir contraseña"
                                   {{ isset($user) ? '' : 'required' }}>
                        </div>

                        @if(isset($user))
                        <div class="col-12">
                            <label class="form-label-h">Estado</label>
                            <div style="display:flex;gap:16px;margin-top:4px">
                                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.9rem">
                                    <input type="radio" name="is_active" value="1"
                                           {{ old('is_active', $user->is_active) == 1 ? 'checked' : '' }}>
                                    <span>Activo</span>
                                </label>
                                <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.9rem">
                                    <input type="radio" name="is_active" value="0"
                                           {{ old('is_active', $user->is_active) == 0 ? 'checked' : '' }}>
                                    <span>Inactivo</span>
                                </label>
                            </div>
                        </div>
                        @endif

                        <div class="col-12 d-flex gap-2 justify-content-end" style="margin-top:8px">
                            <a href="{{ route('users.index') }}" class="btn-outline-brand">Cancelar</a>
                            <button type="submit" class="btn-brand">
                                <i class="fa-solid fa-floppy-disk"></i>
                                {{ isset($user) ? 'Guardar Cambios' : 'Crear Usuario' }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card-halcon">
            <div class="card-header-h">
                <i class="fa-solid fa-shield-halved" style="color:var(--brand)"></i>
                <span style="font-family:'Syne',sans-serif;font-weight:700;">Roles y Permisos</span>
            </div>
            <div class="card-body-h">
                @php
                    $rolesInfo = [
                        'Administrador' => ['color'=>'#6D28D9','icon'=>'fa-crown','desc'=>'Acceso total. Puede registrar usuarios y asignar roles.'],
                        'Ventas'        => ['color'=>'#1D4ED8','icon'=>'fa-handshake','desc'=>'Registra pedidos de clientes y los ingresa al sistema.'],
                        'Compras'       => ['color'=>'#B45309','icon'=>'fa-cart-shopping','desc'=>'Gestiona la adquisición de materiales no disponibles en almacén.'],
                        'Almacén'       => ['color'=>'#065F46','icon'=>'fa-warehouse','desc'=>'Prepara los pedidos para su envío e informa sobre stock.'],
                        'Ruta'          => ['color'=>'#9D174D','icon'=>'fa-truck','desc'=>'Distribuye los pedidos y sube fotos de evidencia.'],
                    ];
                @endphp
                @foreach($rolesInfo as $name => $info)
                <div style="display:flex;gap:12px;margin-bottom:16px;{{ !$loop->last ? 'padding-bottom:16px;border-bottom:1px solid var(--border)' : '' }}">
                    <div style="width:36px;height:36px;border-radius:8px;background:{{ $info['color'] }}18;color:{{ $info['color'] }};display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:.9rem">
                        <i class="fa-solid {{ $info['icon'] }}"></i>
                    </div>
                    <div>
                        <div style="font-family:'Syne',sans-serif;font-size:.85rem;font-weight:700;color:var(--ink)">{{ $name }}</div>
                        <div style="font-size:.78rem;color:var(--ink-soft);line-height:1.5">{{ $info['desc'] }}</div>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>
@endsection
