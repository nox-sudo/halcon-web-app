@extends('layouts.app')

@section('title', 'Usuarios')
@section('page-title', 'Gestión de Usuarios')

@section('content')
<div class="page-header">
    <div>
        <h1>Usuarios</h1>
        <div class="breadcrumb-h">Lista general de usuarios del sistema</div>
    </div>
    <a href="{{ route('users.create') }}" class="btn-brand">
        <i class="fa-solid fa-user-plus"></i> Nuevo Usuario
    </a>
</div>

<div class="card-halcon">
    <div class="card-body-h p-0">
        <table class="table-halcon">
            <thead>
                <tr>
                    <th>Usuario</th>
                    <th>Correo</th>
                    <th>Departamento / Rol</th>
                    <th>Estado</th>
                    <th>Registro</th>
                    <th style="text-align:right">Acciones</th>
                </tr>
            </thead>
            <tbody>
                @forelse($users as $user)
                <tr>
                    <td>
                        <div style="display:flex;align-items:center;gap:10px">
                            <div style="width:36px;height:36px;border-radius:50%;background:var(--brand);display:flex;align-items:center;justify-content:center;font-family:'Syne',sans-serif;font-weight:700;color:#fff;font-size:.8rem;flex-shrink:0">
                                {{ strtoupper(substr($user->name,0,2)) }}
                            </div>
                            <div>
                                <div style="font-weight:600;font-size:.9rem">{{ $user->name }}</div>
                            </div>
                        </div>
                    </td>
                    <td style="color:var(--ink-soft);font-size:.85rem">{{ $user->email }}</td>
                    <td>
                        @php
                            $roleColors = [
                                'admin'     => '#6D28D9',
                                'sales'     => '#1D4ED8',
                                'purchasing'=> '#B45309',
                                'warehouse' => '#065F46',
                                'route'     => '#9D174D',
                            ];
                            $roleName = $user->role->name ?? 'Sin rol';
                            $roleKey  = strtolower($user->role->slug ?? '');
                            $roleColor = $roleColors[$roleKey] ?? '#374151';
                        @endphp
                        <span style="background:{{ $roleColor }}18;color:{{ $roleColor }};border-radius:20px;padding:4px 10px;font-size:.75rem;font-weight:700">
                            {{ $roleName }}
                        </span>
                    </td>
                    <td>
                        @if($user->is_active)
                            <span class="badge-status s-delivered">Activo</span>
                        @else
                            <span class="badge-status s-deleted">Inactivo</span>
                        @endif
                    </td>
                    <td style="font-size:.82rem;color:var(--ink-soft)">{{ $user->created_at->format('d M Y') }}</td>
                    <td>
                        <div class="d-flex gap-2 justify-content-end">
                            <a href="{{ route('users.edit', $user) }}"
                               class="btn-outline-brand" style="padding:6px 10px;font-size:.8rem;" title="Editar">
                                <i class="fa-solid fa-pen"></i>
                            </a>
                            @if($user->id !== auth()->id())
                            <form method="POST" action="{{ route('users.toggle', $user) }}">
                                @csrf @method('PATCH')
                                <button type="submit"
                                    title="{{ $user->is_active ? 'Desactivar' : 'Activar' }}"
                                    style="background:none;border:1.5px solid {{ $user->is_active ? '#EF4444' : '#10B981' }};border-radius:8px;padding:6px 10px;color:{{ $user->is_active ? '#EF4444' : '#10B981' }};cursor:pointer;font-size:.8rem;transition:all .2s"
                                    onmouseover="this.style.background=this.style.color;this.style.color='#fff'"
                                    onmouseout="this.style.background='none';this.style.color=this.style.borderColor">
                                    <i class="fa-solid fa-{{ $user->is_active ? 'user-slash' : 'user-check' }}"></i>
                                </button>
                            </form>
                            @endif
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" style="text-align:center;padding:48px;color:var(--ink-soft)">
                        <i class="fa-solid fa-users fa-2x mb-3 d-block" style="opacity:.3"></i>
                        No hay usuarios registrados.
                    </td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    @if($users->hasPages())
    <div style="padding:16px 24px;border-top:1px solid var(--border)">
        {{ $users->links() }}
    </div>
    @endif
</div>
@endsection
